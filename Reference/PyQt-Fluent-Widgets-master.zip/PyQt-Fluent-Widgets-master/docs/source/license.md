## License
Non-commercial usage is licensed under [GPLv3](./_static/LICENSE). For commercial purposes, please purchase on [official website](https://qfluentwidgets.com/price) to support the development of this project.

Copyright © 2021 by zhiyiYo.