#ifndef EMOJI_H
#define EMOJI_H

#define EMOJI_LEN 96
#define EMOJI_BMP_ROW 6
#define EMOJI_BMP_COL 16

extern const char* g_emojis[EMOJI_LEN];
extern const char* g_emojiText[EMOJI_LEN];

#endif // EMOJI_H
